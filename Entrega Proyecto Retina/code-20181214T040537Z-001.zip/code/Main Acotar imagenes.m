%%
%En esta secci�n borra todo el workspace, y agrega al path las carpetas de
%de lectura y salida
clear all
close all
clc
path = 'C:\Users\Daniel\Desktop\imagenes\';
addpath(genpath(path))
%%
%definir la Base opciones =
%(Base11,Base12,Base13,Base14,Base21,Base22,Base23,Base24,Base31,Base32,Base33,Base34)
base = 'Base11';
nombres = ls(strcat(path,char(base))); %lee los nombres de las fotos
for i = 3:102 % Lee donde si hay imagenes en nombres
I = imread(nombres(i,:));
%%
I_recortada= recortador(I,50); %Llama la funci�n Recortador con argumentos:la foto I  y 50 = el �mbral m�ximo permitido 
%%
%imshow(I_recortada)
%%
I_recortada = imresize(I_recortada,[1378 1378]); %da un tama�o uniforme a todas las imagenes de salida
imwrite(I_recortada,strcat(path,'\Salida\',base,'\',nombres(i,1:(length(nombres(i,:))-3)),'png')) 

end
