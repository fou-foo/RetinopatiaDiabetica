
#setwd("code\\")
library(MASS)
library(readr)
library(caret)
library(beepr)

##Lee el csv de de 4 momentos.
retina<- read_csv("meta4momentos.csv", 
                     col_names = FALSE, col_types = cols(X1 = col_skip(), 
                                                         X2 = col_factor(levels = c("0", "1","2", "3")), X3 = col_skip()))

###Si se quiere Clasificar en las 4 categorias es TRUE, si solo 2 categor�as entonces FALSE
Cuatro_categorias<-T
if(!Cuatro_categorias){
  for (i in 1:1200) {
    if(retina$X2[i]!=0)
      retina$X2[i] = 1
  }
  retina$X2<-factor(retina$X2,levels = c(0,1))
}
###Separa el total en Train y Test (70 y 30)
aux<-sample(nrow(retina), 360)
retina.test<-retina[aux, ]
retina.train<-retina[-aux,]
### Aplica jitter al Train
retina.train.jitered<- as.data.frame(cbind(retina.train[,1],jitter(as.matrix(retina.train[,-1]))))


#Entrena cada uno de m�todos (lda,qda,nn,tree,ada,svm)
lda.retina<-train(y = retina.train.jitered[,1],x =  retina.train.jitered[,-1],method  = 'lda',trControl = trainControl(method = "cv",number = 10,verboseIter = T))
qda.retina<-train(y = retina.train.jitered[,1],x =  retina.train.jitered[,-1],method  = 'qda',trControl = trainControl(method = "cv",number = 10,verboseIter = T))
nn.retina<-train(y = retina.train.jitered[,1],x =  retina.train.jitered[,-1],method  = 'nnet',tuneGrid = expand.grid(size = 10,decay = 0),trControl = trainControl(method = "cv",number = 10,verboseIter = T))
svm.retina<-train(y = as.factor(retina.train.jitered$X2),x =  retina.train[,-1],method  = 'svmLinear2',trControl = trainControl(method = "cv",number = 10,verboseIter = T))
tree.retina<-train(y = retina.train.jitered[,1],x =  retina.train.jitered[,-1],method  = 'rpart2',tuneGrid = expand.grid(maxdepth = 10),trControl = trainControl(method = "cv",number = 10,verboseIter = T))
ada.retina<-train(y = retina.train.jitered[,1],x =  retina.train.jitered[,-1],tuneGrid = expand.grid(mfinal=1,maxdepth = 5),method  = 'AdaBag',trControl = trainControl(method = "cv",number = 10,verboseIter = T))

###Resultados para el accuracy y Kappa en el train
results <- resamples(list(LDA = lda.retina,QDA = qda.retina , NNet = nn.retina, SVM =svm.retina ,Trees= tree.retina,ADA = ada.retina ))
summary(results)
bwplot(results)
#dotplot(results)
#densityplot(results)


#Revisi�n de accuracy en el conjunto TEST

Lista<-list(lda.retina,qda.retina,nn.retina,svm.retina,tree.retina,ada.retina)
cont<-1
accuracy<-rep(0,6)
for (i in Lista) {
  y_pred<-predict(i,newdata = retina.test)
  confusion<-table(retina.test$X2,y_pred)
  accuracy[cont]<-sum(diag(confusion))/sum(confusion)
  #confusion
  cont<-cont+1
}

#accuracy
Lista[[which.max(accuracy)]]$method
max(accuracy)
