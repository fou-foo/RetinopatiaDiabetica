function rec = recortador(I,u)
%buscar derecha e izquierda
rangos_r=max(I(:,:,1))-min(I(:,:,1));
rangos_g=max(I(:,:,2))-min(I(:,:,2));
rangos_b=max(I(:,:,3))-min(I(:,:,3));

rangos = [rangos_r;rangos_g;rangos_b];
rangos = mean(rangos);
x_min= (min(find(rangos>u)));
x_max= (max(find(rangos>u)));

%buscar arriba y abajo
rangos_r=max(I(:,:,1),[],2).'-min(I(:,:,1),[],2).';
rangos_g=max(I(:,:,2),[],2).'-min(I(:,:,2),[],2).';
rangos_b=max(I(:,:,3),[],2).'-min(I(:,:,3),[],2).';

rangos = [rangos_r;rangos_g;rangos_b];
rangos = mean(rangos);
y_min= min(find(rangos>u));
y_max= max(find(rangos>u));

rec = I(y_min:y_max,x_min:x_max,:);

end